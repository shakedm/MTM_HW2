#ifndef NEW_FOLDER_LIBRARY_H
#define NEW_FOLDER_LIBRARY_H

void hello(void);

#endif